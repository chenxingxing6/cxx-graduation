export const COMMON = {
    PAGE_SIZE: 20,
    PAGE_NUM: 1,
};

