export default {
    VERSION: '2.2.10',
};
