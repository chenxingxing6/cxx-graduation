package com.example.modules.oss.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.example.modules.oss.entity.SysOssEntity;

/**
 * 文件上传
 */
public interface SysOssDao extends BaseMapper<SysOssEntity> {
	
}
