package com.example.modules.job.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.example.modules.job.entity.ScheduleJobLogEntity;

/**
 * 定时任务日志
 */
public interface ScheduleJobLogDao extends BaseMapper<ScheduleJobLogEntity> {

}
