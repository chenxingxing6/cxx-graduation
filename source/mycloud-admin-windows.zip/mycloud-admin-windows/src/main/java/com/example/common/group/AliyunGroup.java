package com.example.common.group;

/**
 * 阿里云
 */
public interface AliyunGroup {
}
