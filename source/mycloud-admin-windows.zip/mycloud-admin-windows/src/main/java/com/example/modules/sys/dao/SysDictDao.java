package com.example.modules.sys.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.example.modules.sys.entity.SysDictEntity;

/**
 * 数据字典
 */
public interface SysDictDao extends BaseMapper<SysDictEntity> {
	
}
