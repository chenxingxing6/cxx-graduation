package com.example.modules.front.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.example.modules.front.entity.SysDiskEntity;

/**
 * 企业网盘目录
 * 
 * @author 蓝星花
 * @date 2019-04-02 22:27:52
 */
public interface SysDiskDao extends BaseMapper<SysDiskEntity> {
	
}
