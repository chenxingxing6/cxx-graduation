package com.example.modules.sys.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.example.modules.sys.entity.SysLogEntity;

/**
 * 系统日志
 * @Author: cxx
 * @Date: 2019/1/1 17:35
 */
public interface SysLogDao extends BaseMapper<SysLogEntity> {
	
}
