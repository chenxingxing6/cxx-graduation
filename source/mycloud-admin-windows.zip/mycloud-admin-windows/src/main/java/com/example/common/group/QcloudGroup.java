package com.example.common.group;

/**
 * 腾讯云
 */
public interface QcloudGroup {
}
