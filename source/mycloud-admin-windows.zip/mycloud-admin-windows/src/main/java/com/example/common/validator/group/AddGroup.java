package com.example.common.validator.group;

/**
 * 新增数据 Group
 * @Author: cxx
 * @Date: 2019/1/1 16:30
 */
public interface AddGroup {
}
