package com.example.modules.sys.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.example.modules.sys.entity.SysRoleEntity;

/**
 * 角色管理
 */
public interface SysRoleDao extends BaseMapper<SysRoleEntity> {
	

}
