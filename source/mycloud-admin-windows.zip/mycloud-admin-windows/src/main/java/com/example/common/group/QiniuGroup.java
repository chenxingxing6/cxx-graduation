package com.example.common.group;

/**
 * 七牛
 */
public interface QiniuGroup {
}
